import os
from handwriting.models import *


# file upload parameters
UPLOAD_FOLDER = './uploads/'
ALLOWED_EXTENSIONS = set(['pdf','wav','mp3'])


# Check if the uploaded file is in listed formats or not
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS

# Write the code for Text to Handwriting Conversion
