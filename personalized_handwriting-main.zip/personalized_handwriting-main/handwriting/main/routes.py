import os
from flask import Blueprint, render_template, redirect, url_for, flash,request
from flask.globals import request
from flask_login.utils import login_required
from flask_login import current_user
from flask_mail import Message
from werkzeug.utils import secure_filename
from handwriting import mail,UPLOAD_FOLDER,DOWNLOAD_FOLDER
from datetime import datetime
from handwriting.main.utils import allowed_file
from handwriting.main.handwriting import Handwriting, from_mp3, from_pdf

main = Blueprint('main',__name__)

# Create an object of Class Handwriting
handwriting = Handwriting()

# file upload parameters
ALLOWED_EXTENSIONS = set(['pdf','wav','mp3'])

# Landing Page
@main.route('/')
def homepage():
    return render_template('index.html')

# Contact-Us Page
@main.route('/contact-us/', methods=['GET','POST'])
def contactpage():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')

        msg = Message(subject=subject, recipients=['abhaporwal12@gmail.com','mishra.sambitkumar77@gmail.com'])
        msg.body = f"Hi,\n\nYou have a new message from {name}! The message is:\n{message}.\nPlease get back to {name} on {email}.\n\nHave a nice day!"
        mail.send(msg)
        flash('Your query has been sent successfully!', 'success')
    return render_template('contactpage.html')

# Dashboard page
@main.route('/dashboard/', methods=['GET','POST'])
@login_required
def dashboard():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(url_for('main.dashboard'))
        file = request.files['file']
        extension = file.filename[-4:]
        filename = ''
        pdf_attribute = ''
        speech_attribute = ''
        download_path = ''
        if file.filename == '':
            return redirect(url_for('main.dashboard'))
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filename = ((current_user.email).split('@'))[0]
            filename = str(filename)+extension
            file.save(os.path.join(UPLOAD_FOLDER, filename))
        try:
            path = ('./uploads/'+filename)
            print(path)
            if extension == '.pdf':
                data = from_pdf(path)
            else:
                data = from_mp3(path)
            handwriting.text_images(data)
            handwriting.to_pdf()
            download_path = ''
            if extension == '.pdf':
                speech_attribute = 'hidden'
                pdf_attribute = 'visible'
            else:
                pdf_attribute = 'hidden'
                speech_attribute = 'visible'
            flash('Your file has been converted successfully! Click the send button to receive it!', 'success')
        except:
            flash('Something went wrong!', 'error')
        return render_template('dashboard.html', pdf_attribute=pdf_attribute, speech_attribute=speech_attribute, download_path=download_path)
    return render_template('dashboard.html',pdf_attribute='hidden', speech_attribute='hidden')


@main.route('/send-output/', methods=['GET','POST'])
@login_required
def output():
    if request.method == 'POST':
        path = DOWNLOAD_FOLDER+'/output.pdf'
        try:
            msg = Message('Here is your output, Hastlekh!', recipients=['abhaporwal12@gmail.com',current_user.email])
            msg.body = f"Dear {current_user.name},\n\nYour converted pdf file is attached below! Thanks for using our services!\n\nRegards\nTeam Hastlekh"
            with open(path, 'rb') as fh:
                msg.attach(path,"application/pdf", fh.read())
            mail.send(msg)
            flash('Your output file has been mailed to you!', 'success')
        except:
            flash('Something went wrong!', 'error')
    return redirect(url_for('main.dashboard'))

   