from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import OperationStatusCodes
from azure.cognitiveservices.vision.computervision.models import VisualFeatureTypes
import azure.cognitiveservices.speech as speechsdk
from msrest.authentication import CognitiveServicesCredentials

from array import array
import os
from PIL import Image
from fpdf import FPDF
import time

subscription_key = "eba364eaa0ec4b32a9f36fd3b330bcc6"
endpoint = "https://abha.cognitiveservices.azure.com/"

def from_mp3(path):
    speech_config = speechsdk.SpeechConfig(subscription="f38e132fed6e41a0b7e796a09d21be11", region="centralindia")
    audio_input = speechsdk.AudioConfig(filename=path)
    speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_input)
    
    result = speech_recognizer.recognize_once_async().get()
    return result.text
    

def from_pdf(path):
    print("===== Read File - remote =====")
    computervision_client = ComputerVisionClient(endpoint, CognitiveServicesCredentials(subscription_key))
    read_url = open(path,"rb")

    read_response = computervision_client.read_in_stream(read_url,  raw=True)

    read_operation_location = read_response.headers["Operation-Location"]
    # Grab the ID from the URL
    operation_id = read_operation_location.split("/")[-1]

    # Call the "GET" API and wait for it to retrieve the results 
    while True:
        read_result = computervision_client.get_read_result(operation_id)
        if read_result.status not in ['notStarted', 'running']:
            break
        time.sleep(1)
    data=''
    # Print the detected text, line by line
    if read_result.status == OperationStatusCodes.succeeded:
        for text_result in read_result.analyze_result.read_results:
            for line in text_result.lines:
                data+=(line.text)  
    return data
    

class Handwriting:
    def __init__(self):
        self.background = Image.open("./uploads/background/bg.png")
        self.sizeOfSheet = self.background.width
        self.gap, self._ = 0, 0
        self.allowed_char = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM,.-?!() 1234567890[]:"=+\/;#*' 
        self.p = 0


    def handwritten(self,char):
        if char == '\n':
            pass
        else:
            try:
                char.lower()
                cases = Image.open(f"./uploads/data/{char}.JPG")
                self.background.paste(cases, (self.gap, self._))
                size = cases.width
                self.gap += size
                del cases
            except:
                pass


    def letter_name(self,word):        
        if self.gap > self.sizeOfSheet - 95 * (len(word)):
            self.gap = 0
            self._ += 150
        for letter in word:
            if letter in self.allowed_char:
                if letter.islower():
                    pass
                elif letter.isupper():
                    letter = letter.lower()
                    letter += 'upper'
                elif letter == '.':
                    letter = "fullstop"
                elif letter == '!':
                    letter = 'exclaimation'
                elif letter == '?':
                    letter = 'question'
                elif letter == ',':
                    letter = 'comma'
                elif letter == '(':
                    letter = 'opencb'
                elif letter == ')':
                    letter = 'closecb'
                elif letter == '-':
                    letter = 'hyphen'
            self.handwritten(letter)


    def find_word(self,Input):
        wordlist = Input.split(' ')
        for i in wordlist:
            self.letter_name(i)
            self.handwritten('space')


    def text_images(self,data):
        try:
            l = len(data)
            nn = len(data) // 1500
            chunks, chunk_size = len(data), len(data) // (nn + 1)
            self.p = [data[i:i + chunk_size] for i in range(0, chunks, chunk_size)]

            for i in range(0, len(self.p)):
                self.find_word(self.p[i])
                self.handwritten('\n')
                self.background.save('./processed/%doutt.png' % i)
                background1 = Image.open("./uploads/background/bg.png")
                self.background = background1
                self.gap = 0
                self._ = 0
        except ValueError as E:
            print("{}\nTry again".format(E))


    def to_pdf(self):
        print("------------------- Converting to PDF -------------------")
        list_image = []
        for i in range(0, len(self.p)):
            list_image.append('./processed/%doutt.png' % i)
        cover = Image.open(list_image[0])
        width, height = cover.size
        pdf = FPDF(unit="pt", format=[width, height])
        for i in range(0, len(list_image)):
            pdf.add_page()
            pdf.image(list_image[i], 0, 0)
        pdf.output("./processed/output.pdf", "F")


