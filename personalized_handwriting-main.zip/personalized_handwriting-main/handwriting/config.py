import os
class Config:
    SECRET_KEY  = 'intellectualpropertyofSKM'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///'+\
        os.path.join(os.getcwd(),'db.sqlite3')
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'team.hastlekh@gmail.com'
    MAIL_DEFAULT_SENDER = 'team.hastlekh@gmail.com'
    MAIL_PASSWORD = 'Abha@sambit12'
    # SECRET_KEY  = os.getenv('SECRET_KEY')
    # SQLALCHEMY_DATABASE_URI = 'sqlite:///'+\
    #     os.path.join(os.getcwd(),'db.sqlite3')
    # MAIL_SERVER = os.environ.get('MAIL_SERVER')
    # MAIL_PORT = 587
    # MAIL_USE_TLS = True
    # MAIL_USERNAME = os.environ.get('MAIL_USERNAME')
    # MAIL_DEFAULT_SENDER = os.environ.get('MAIL_DEFAULT_SENDER')
    # MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD')