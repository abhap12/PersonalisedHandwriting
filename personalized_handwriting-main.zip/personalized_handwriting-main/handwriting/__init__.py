import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_manager
from flask_mail import Mail
from flask_script import Manager,Server
from flask_migrate import Migrate,MigrateCommand
from handwriting.config import Config

db = SQLAlchemy()
mail = Mail()
login_manager = LoginManager()
migrate = Migrate()
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'info'
UPLOAD_FOLDER = './uploads'
DOWNLOAD_FOLDER = './processed'

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)
    mail.init_app(app)

    migrate.init_app(app,db)

    from handwriting.main.routes import main
    from handwriting.auth.routes import auth
    from handwriting.errors.handlers import errors

    app.register_blueprint(main)
    app.register_blueprint(auth)
    app.register_blueprint(errors)

    return app

manager = Manager(create_app)
manager.add_command('db', MigrateCommand)
manager.add_command('runserver', Server(host='127.0.0.1', port=5000, use_debugger=True))
